<? include_once("includes/pagesource.php"); ?>

<body>
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid banner p-0">
        <img src="images/banner-4.jpg" class="ban-bk">
        <div class="container position-relative h-100" style="z-index: 1;">
            <div class="row align-items-center h-100">
                <div class="col-12 col-md-6 banner-content">
                    <div>
                        <h2 class="animate__zoomIn animate__animated wow">LEARNING MADE <span>EASY</span></h2>
                        <h5 class="animate__zoomIn animate__animated wow">Digital classes with best teachers & study materials</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-0 sign-in-wrap">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 top-wrap py-6 px-0 d-md-flex justify-content-between">
                    <div class="whyus-in d-flex align-items-start animate__fadeInUp animate__animated wow">
                        <img src="images/schollar.png">
                        <div class="ml-3">
                            <h5>Scholarship Facility</h5>
                            <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown</p>
                        </div>
                    </div>
                    <div class="whyus-in d-flex align-items-start my-4 my-md-0 mx-md-4 animate__fadeInUp animate__animated wow">
                        <img src="images/skilled.png">
                        <div class="ml-3">
                            <h5>Skilled Lecturers</h5>
                            <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown</p>
                        </div>
                    </div>
                    <div class="whyus-in d-flex align-items-start animate__fadeInUp animate__animated wow">
                        <img src="images/library.png">
                        <div class="ml-3">
                            <h5>Book Library & Store</h5>
                            <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row ">
                <div class="col-12 abt-main-wrap">
                    
                    <img src="images/top-lft-round.jpeg ">
                    <div class="abt-info">
                        <div class="col-12 main-heaing">
                            <h2 class="animate__fadeInUp animate__animated wow">Preparing for <span>NEET?</span> Come learn at NEET-O-METER</h2>
                        </div>
                        <div class="content">
                            <p class="animate__fadeInUp animate__animated wow">Prepare for NEET 2022 or 2023 with the most thorough and exhaustive online homeroom program by the world's biggest Ed-Tech organization.</p>

                            <p class="animate__fadeInUp animate__animated wow">Ordinary online classes by India's driving NEET coaches</p>

                            <p class="animate__fadeInUp animate__animated wow">NEET-O-METER offer you Online Classes that will be directed 3-5 times each week by India's Best NEET Trainers. This will assist you with understanding the idea altogether and guarantee that every one of your questions is cleared.</p>

                            <p class="animate__fadeInUp animate__animated wow">In-depth conversation of Daily Practice Problems (DPPs) and Practice Sheets</p>

                            <p class="animate__fadeInUp animate__animated wow">The very much planned and organized DPP will help you amend the ideas consistently for every one of the subjects. Practice Sheet conversation guarantees that you figure out how to apply the ideas educated in the class.</p>

                            <p class="animate__fadeInUp animate__animated wow">All India Tests to benchmark yourself against different students</p>

                            <p class="animate__fadeInUp animate__animated wow">NEET-O-METER All India Test Series (AITS) for NEET led once at regular intervals will measure your exhibition PAN India and improve your test-taking abilities. Each test is trailed by definite input to assist you with understanding the holes in your planning.</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid blue-sec py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="animate__fadeInUp animate__animated wow text-center">Start your <span>NEET</span> preparation now</h2>
                    <p class="animate__fadeInUp animate__animated wow text-center">You don't have to struggle alone, you've got our assistance and help.</p>
                </div>
                <div class="col-12 tabcontent active">
                    <div class="team-box row mb-5">
                        <div class="prep-cell animate__fadeInUp animate__animated wow" style="background:#DD246E;">
                            <div class="prep-img-box">
                                <img src="images/study-material.png">
                            </div>
                            <h4>Smart Study Material</h4>
                            <ul>
                                <li>20000+ Chapter wise <b>NEET questions</b></li>
                                <li>5000+ NEET concept wise <b>videos</b></li>
                                <li>1200+ Most asked <b>NEET concepts</b></li>
                                <li>1000+ Most difficult <b>NEET concepts</b></li>
                                <li>10 years solved <b>NEET question papers</b></li>
                                <li>5000+ Concept wise <b>Flash Cards</b></li>
                                <li>Weekend <b>Live Classes</b></li>
                            </ul>
                        </div>


                        <div class="prep-cell animate__fadeInUp animate__animated wow" style="background:#8007E6 ;">
                            <div class="prep-img-box">
                                <img src="images/mocktest.png">
                            </div>
                            <h4>NEET Mock Test Series</h4>
                            <ul>
                                <li>Unlimited - <b>chapter wise tests</b></li>
                                <li>Unlimited - <b>subject wise tests</b></li>
                                <li>Unlimited - <b>Full mock tests</b></li>
                            </ul>
                        </div>


                        <div class="prep-cell animate__fadeInUp animate__animated wow" style="background:#0CAE74;">
                            <div class="prep-img-box">
                                <img src="images/performance.png">
                            </div>
                            <h4>Performance Analysis</h4>
                            <ul>
                                <li><b>Prepmeter</b> - Check how ready you are for NEET</li>
                                <li><b>Strength Sheet</b> - Know your top performing areas</li>
                                <li><b>Weakness Sheet</b> - Know your areas to improve</li>
                                <li><b>Skills Graph</b> - Know how your skill-set is improving</li>
                                <li><b>Rank Predictor</b> - Estimate your rank in advance</li>
                            </ul>
                        </div>
                    </div>
                    <h4 class="prep-btm-text animate__fadeInUp animate__animated wow">Live NEET doubt solving with <span>24x7</span> faculty support</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative service-main-wrap" id="feature">
        <img src="assets/ser-bk.png" class="service-bk">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">

                    <h2 class="text-white text-center animate__fadeInUp animate__animated wow"><span>Feature</span> of NEET-O-METER.
                    </h2>
                    <p class="text-white text-center animate__fadeInUp animate__animated wow">Advance systems make us uniq, help you to grow your career</p>
                </div>
                <div class="col-12 mb-5 pb-5">
                    <div class="team-box row p-0 m-0">
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/ai.png">
                                <h4>AI DRIVEN PERSONALISED MENTOR</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/mocktest.png">
                                <h4>UNLIMITED MOCK TEST+ PREVIOUS PAPERS</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/timetable.png">
                                <h4>CUSTOMISED TIMETABLE</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/performance.png">
                                <h4>PERFORNMENCE ANALYSIS</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/exam.png">
                                <h4>EXAM STRATEGY PLANNING</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/study-material.png">
                                <h4>SMART STUDY MATERIAL</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid blue-sec ">
        <div class="container">
            <div class="row">
                <div class="col-12" style="z-index: 1;">
                    <div class="frm-wrap">
                        <div class="pr-com-box animate__fadeInUp animate__animated wow">
                            <img src="images/neem.png">
                            <p>Start from</p>
                            <h4>14,999/-</h4>
                        </div>
                        <div class="pr-com-box animate__fadeInUp animate__animated wow">
                            <img src="images/vedantu.png">
                            <p>Start from</p>
                            <h4>64,799/-</h4>
                        </div>
                        <div class="pr-com-box animate__fadeInUp animate__animated wow">
                            <img src="images/Byju's_logo.svg.png">
                            <p>Start from</p>
                            <h4>60,000/-</h4>
                        </div>
                        <div class="pr-com-box animate__fadeInUp animate__animated wow">
                            <img src="images/topper.png">
                            <p>Start from</p>
                            <h4>40,000/-</h4>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-10 offset-md-1 about-counter-cell py-6">
                    <div class="d-flex align-items-center justify-content-center">
                        <div class=" d-flex align-items-center animate__fadeInRight animate__animated wow">
                            <img src="images/concepts.png" class="mr-4">
                            <div>
                                <h4>5000+</h4>
                                <h6>CONCEPTS</h6>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-center ">
                        <div class=" d-flex align-items-center animate__fadeInRight animate__animated wow">
                            <img src="images/viddeolcture.png" class="mr-4">
                            <div>
                                <h4>250+</h4>
                                <h6>VIDEO e-LECTURES</h6>
                            </div>
                        </div>
                    </div>
                    <div class=" d-flex align-items-center justify-content-center">
                        <div class=" d-flex align-items-center animate__fadeInRight animate__animated wow">
                            <img src="images/faculty.png" class="mr-4">
                            <div>
                                <h4>24x7</h4>
                                <h6>FACULTY SUPPORT</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative " id="plans">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center animate__fadeInUp animate__animated wow">Learn Prep Plans now</h2>
                </div>
                <div class="col-12 tabcontent">
                    <div class="team-box row m-0 p-0">
                        <div class="prep-cell p-0 animate__fadeInUp animate__animated wow">
                            <div class="price-box blue">
                                <h2 class="price"><i class="fas fa-rupee-sign"></i> 14999<span>/ month</span></h2>

                                <div class="price-cell">
                                    <h3 class="course-name">CRASH COURSE</h3>
                                    <ul class="course-detail">
                                        <li>1x option 1</li>
                                        <li>2x option 2</li>
                                        <li>3x option 3</li>
                                        <li>Free option 4</li>
                                        <li>Unlimited option 5</li>
                                    </ul>
                                    <a>Buy Now</a>
                                </div>
                            </div>
                        </div>
                        <div class=" prep-cell p-0 animate__fadeInUp animate__animated wow">
                            <div class="price-box pink">
                                <h2 class="price"><i class="fas fa-rupee-sign"></i> 24999<span>/ month</span></h2>

                                <div class="price-cell">
                                    <h3 class="course-name">CRASH COURSE2</h3>
                                    <ul class="course-detail">
                                        <li>1x option 1</li>
                                        <li>2x option 2</li>
                                        <li>3x option 3</li>
                                        <li>Free option 4</li>
                                        <li>Unlimited option 5</li>
                                    </ul>
                                    <a>Buy Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <? include_once("includes/whyus.php"); ?>
    <? include_once("includes/testimonial.php"); ?>
    <div class="container-fluid copy-right ">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 ">
                    <div class="d-md-flex align-items-center justify-content-between">
                        <p class="mb-0">© Copyright 2022</p>
                        <p class="mb-0 ft-social">
                            <a><i class="fab fa-facebook-f"></i></a>
                            <a><i class="fab fa-twitter"></i></a>
                            <a><i class="fab fa-linkedin-in"></i></a>
                        </p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</body>
<script src="js/jquery.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/odometer.js"></script>
<script src="js/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
<script>
    $(document).ready(function() {
        $('.has-arrow').click(function() {
            if ($(this).hasClass("active")) {
                $(".sub-ui").slideUp();
                $(".has-arrow").removeClass("active");
            } else {
                $(".sub-ui").slideUp();
                $(".has-arrow").removeClass("active");
                $(this).parent().find(".sub-ui").slideToggle();
                $(this).parent().find(".has-arrow").toggleClass("active");
            }
        });
    });
</script>
<script>
    AOS.init({
        easing: 'ease-in-out-sine'
    });

    $('.service-owl').owlCarousel({
        loop: true,
        margin: 60,

        dots: false,
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            600: {
                items: 1,
                nav: false,
            },
            1200: {
                items: 3,
                nav: true,
            },
            1500: {
                items: 4,
                nav: true,
            }
        }
    })

    $('.client-owl').owlCarousel({
        loop: true,
        margin: 30,
        nav: false,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 6
            }
        }
    })

    $('.banner-owl').owlCarousel({
        loop: true,
        autoplay: true,
        autoplayTimeout: 4000,
        margin: 0,
        nav: false,
        dots: true,
        animateOut: 'fadeOut',
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })

    $('.testi-owl').owlCarousel({
        loop: true,
        margin: 30,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1200: {
                items: 1
            },
            1500: {
                items: 1
            }
        }
    })
    $('.tec-owl').owlCarousel({
        loop: true,
        margin: 30,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 6
            }
        }
    })
    $(document).ready(function() {
        $('.tablinks').click(function() {
            $(".tabcontent").removeClass('active');
            $(".tabcontent[data-id='" + $(this).attr('data-id') + "']").addClass("active");
            $(".tablinks").removeClass('active-a');
            $(this).addClass('active-a');
        });
        $('.tab-links').click(function() {
            $(".tab-content").removeClass('active');
            $(".tab-content[data-id='" + $(this).attr('data-id') + "']").addClass("active");
            $(".tab-links").removeClass('active-a');
            $(this).addClass('active-a');
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('.has-drop').click(function() {
            if ($(".drop-menu[data-id='" + $(this).attr('data-id') + "']").hasClass("active")) {
                $(".drop-menu").hide().removeClass('active');
                $(".has-drop").removeClass('active-a');
                $(".has-drop").removeClass('active');
            } else {
                $(".drop-menu").hide().removeClass('active');
                $(".drop-menu[data-id='" + $(this).attr('data-id') + "']").show().addClass("active");
                $(".has-drop").removeClass('active-a');
                $(this).parent().find(".has-drop").addClass('active-a');
                $(this).parent().find(".has-drop").addClass('active');
            }
        });
    });
</script>
<script src="js/wow.js"></script>
<script>
    new WOW().init();

    function gotoTop(top) {

        $("html, body").animate({

            scrollTop: top + "px"

        }, 'slow');

    }
</script>

</html>